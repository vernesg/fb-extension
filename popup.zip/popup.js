document.getElementById("extractBtn").addEventListener("click", function() {
  chrome.storage.local.get("facebookTokens", function(data) {
    let tokens = data.facebookTokens;
    let tokenDisplay = document.getElementById("tokens");

    if (tokens && tokens.length > 0) {
      tokenDisplay.textContent = "Tokens Found: \n" + tokens.join("\n");
    } else {
      tokenDisplay.textContent = "No tokens found. Please make sure you're logged into Facebook.";
    }
  });
});